### Use ALCPlugFix to fix headset switching
1. Double-click `install.command`
2. Enter the admin password
3. Restart
4. Plug in the headset for testing

***Note:*** If the headset does not sound, you can open the terminal input
```
hda-verb 0x19 0x707 0x20
```